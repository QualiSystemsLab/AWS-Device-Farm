import os
print 'install_device_farm_app called: ' + str(os.environ)
